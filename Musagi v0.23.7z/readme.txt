    Musagi  0.23
 ------------------
  by DrPetter, 2009
 drpetter@gmail.com
   www.drpetter.se


See documentation/index.html for proper (though non-final) documentation.


Disclaimer:

Use this program at your own risk.
It's still beta and not thoroughly tested. If your songs end up corrupt you should let me know but not get furious.
Save often and to several files (song1.smu, song2.smu, song3.smu etc...) in case something does go wrong.

