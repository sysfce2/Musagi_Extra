Open files with smuplay.exe to play them.
An icon will appear in the system tray.
Right-click on it to bring up a small menu
or left-click on the icon to play the next song.
Opening more songs while playing will queue them.
The program exits once the last song has been played.

For maximum convenience, smuplay tries to determine
the most sensible starting position for each song,
as well as a suitable volume level.
This seems to work most of the time,
but don't be alarmed if it doesn't...


How to associate .smu files with smuplay in Windows XP
------------------------------------------------------

* Start Windows file explorer
* Go to Tools->Folder Options
* Click the File Types tab

* Click the New button
* Write SMU as file extension and hit OK
* Click the Advanced button
* Write Musagi Song in the uppermost box
* Click the Change Icon... button
* Browse to document.ico and hit OK
* Click New... (in Actions)
* Write Play in the Action box
* Click Browse... and find smuplay.exe
* Add "%1" (with quotes) after smuplay.exe in the Application box

* Make sure it says the following:
[some path]\smuplay.exe "%1"

(where [some path] is wherever you put smuplay,
 note the space between smuplay.exe and "%1")

* Hit OK, OK and OK
* Done
